<?php
if (!defined('ABSPATH')) { exit; }

class Maskara_Callback {
    public function __construct() {
        add_action('rest_api_init', array($this, 'register_routes'));
    }

    public function register_routes() {
        register_rest_route('maskara/v1', '/verification-result', array(
            'methods' => 'POST',
            'callback' => array($this, 'handle_result'),
            'permission_callback' => array($this, 'authorize'),
        ));
    }

    public function authorize($request) {
        $secret = (string) get_option('maskara_webhook_secret', '');
        $api_key = (string) get_option('maskara_api_key', '');
        $header_secret = (string) $request->get_header('x-webhook-secret');
        $header_key = (string) $request->get_header('x-api-key');
        $header_sig = (string) $request->get_header('x-maskara-signature');

        if ($secret && $header_secret && hash_equals($secret, $header_secret)) return true;
        if ($api_key && $header_key && hash_equals($api_key, $header_key)) return true;
        if ($secret && $header_sig) {
            $expected = hash_hmac('sha256', $request->get_body(), $secret);
            if (hash_equals($expected, $header_sig)) return true;
        }
        return new WP_Error('maskara_forbidden', 'Unauthorized', array('status' => 401));
    }

    public function handle_result($request) {
        $body = $request->get_json_params();
        if (!is_array($body)) {
            return new WP_Error('maskara_bad_request', 'Invalid JSON', array('status' => 400));
        }

        $outcome = strtoupper((string) ($body['outcome'] ?? ''));
        $status  = strtoupper((string) ($body['status'] ?? ($body['verifyStatus'] ?? '')));
        $external_id = $body['externalId'] ?? ($body['wooOrderId'] ?? null);
        $order_number = isset($body['orderNumber']) ? ltrim((string) $body['orderNumber'], '#') : '';

        $order = null;
        if ($external_id) $order = wc_get_order(absint($external_id));
        if (!$order && $order_number !== '') $order = wc_get_order(absint($order_number));
        if (!$order) {
            return new WP_Error('maskara_not_found', 'Order not found', array('status' => 404));
        }

        Maskara_Order_Columns::apply_payload($order, $body);

        $confirmed = in_array($outcome, array('CONFIRMED', 'VERIFIED'), true)
            || in_array($status, array('VERIFIED', 'CONFIRMED'), true);
        $cancelled = in_array($outcome, array('CANCELLED'), true)
            || in_array($status, array('CANCELLED'), true);
        $calling   = in_array($status, array('CALLING'), true);
        $failed    = in_array($status, array('FAILED'), true);

        if ($calling) {
            $order->add_order_note(sprintf(
                'Maskara: verification call in progress (attempt %d).',
                absint($body['callAttempts'] ?? $order->get_meta('_maskara_call_count'))
            ));
            $order->save();
            return array('ok' => true, 'orderId' => $order->get_id(), 'verifyStatus' => 'calling');
        }

        if ($confirmed) {
            $new_status = apply_filters('maskara_confirmed_order_status', 'processing', $order, $body);
            $order->update_status($new_status, 'Maskara: customer confirmed via AI voice call.');
            $order->update_meta_data('_maskara_verify_status', 'verified');
            $order->update_meta_data('_maskara_verification', 'confirmed');
            if (!$order->get_meta('_maskara_courier_status')) {
                $order->update_meta_data('_maskara_courier_status', 'processing');
            }
            $order->save();

            $pathao = null;
            if (class_exists('Maskara_Pathao') && Maskara_Pathao::is_enabled()) {
                $pathao = Maskara_Pathao::create_order_from_wc($order);
                if (is_wp_error($pathao)) {
                    $order->add_order_note('Pathao auto-submit failed: ' . $pathao->get_error_message());
                } elseif (!empty($pathao['consignment'])) {
                    $order->update_meta_data('_maskara_courier_status', 'processing');
                    $order->save();
                }
            }

            return array(
                'ok' => true,
                'orderId' => $order->get_id(),
                'status' => $new_status,
                'verifyStatus' => 'verified',
                'pathao' => is_wp_error($pathao) ? array('error' => $pathao->get_error_message()) : $pathao,
            );
        }

        if ($cancelled) {
            $new_status = apply_filters('maskara_cancelled_order_status', 'cancelled', $order, $body);
            $order->update_status($new_status, 'Maskara: customer cancelled via AI voice call.');
            $order->update_meta_data('_maskara_verify_status', 'cancelled');
            $order->update_meta_data('_maskara_verification', 'cancelled');
            $order->save();
            return array('ok' => true, 'orderId' => $order->get_id(), 'status' => $new_status, 'verifyStatus' => 'cancelled');
        }

        if ($failed) {
            $order->update_meta_data('_maskara_verify_status', 'failed');
            $order->add_order_note('Maskara: all verification call attempts failed.');
            $order->save();
            return array('ok' => true, 'orderId' => $order->get_id(), 'verifyStatus' => 'failed');
        }

        $order->add_order_note('Maskara update: outcome=' . $outcome . ' status=' . $status);
        $order->save();
        return array('ok' => true, 'orderId' => $order->get_id(), 'ignored' => true);
    }
}
