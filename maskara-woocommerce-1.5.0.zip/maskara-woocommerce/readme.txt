=== Maskara Order Verification for WooCommerce ===
Contributors: maskara
Tags: woocommerce, cod, order verification, bangla, maskara, pathao, courier
Requires at least: 5.8
Tested up to: 6.7
Requires PHP: 7.4
Stable tag: 1.5.0
License: GPLv2 or later

WooCommerce → Maskara AI voice verify → Completed + Pathao auto-deploy. Miss/cancel → Cancelled.

== Description ==

* Order sync to Maskara for Bangla AI voice confirmation
* On confirm: WooCommerce status → Completed + Pathao courier auto-deploy
* On miss / cancel: WooCommerce status → Cancelled
* Orders list: Verify, Calls (x/10), Courier stage columns
* Plugins page auto-update from Maskara
* Dashboard: Delivered, In Transit, Returned, Success Rate

== Installation ==

1. Maskara merchant dashboard → API Keys → Create new key
2. WordPress Admin → Plugins → Upload → maskara-woocommerce.zip
3. Activate the plugin
4. Maskara → Settings → enter API URL, API Key, Pathao credentials
5. Click "Test Connection" then "Connect to Maskara"
6. Enable Pathao for auto-deploy on verify

== Changelog ==

= 1.5.0 =
* Verify → Completed + Pathao auto-deploy
* No-answer / cancel → Cancelled
* WordPress Plugins page shows Update when new version available

= 1.4.0 =
* Verify / Calls / Courier columns on WooCommerce Orders

= 1.3.0 =
* Courier dashboard + Pathao status sync
