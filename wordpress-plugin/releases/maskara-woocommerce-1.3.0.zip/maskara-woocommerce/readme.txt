=== Maskara Order Verification for WooCommerce ===
Contributors: maskara
Tags: woocommerce, cod, order verification, bangla, maskara, pathao, courier
Requires at least: 5.8
Tested up to: 6.7
Requires PHP: 7.4
Stable tag: 1.3.0
License: GPLv2 or later

WooCommerce → Maskara AI voice verify → confirm হলে auto Pathao dispatch + delivery analytics dashboard.

== Description ==

* Order sync to Maskara for Bangla AI voice confirmation
* On confirm: WooCommerce status → processing + Pathao courier auto-submit
* WordPress dashboard: Delivered, In Transit, Returned, Delivery Success Rate
* Hourly Pathao status sync + manual Sync now

== Installation ==

1. Maskara merchant dashboard → API Keys → Create new key
2. WordPress Admin → Plugins → Upload → maskara-woocommerce.zip
3. Activate the plugin
4. Maskara → Settings → enter API URL, API Key, Pathao credentials
5. Click "Test Connection" then "Connect to Maskara"
6. Open Maskara → Dashboard for analytics

== Changelog ==

= 1.3.0 =
* Courier Sync Pro–style WP dashboard (Delivered / In Transit / Returned / Success Rate)
* Pathao shipment tracking table + hourly status sync
* Shipments list page with per-order sync

= 1.2.1 =
* Pathao auto-submit on Maskara confirm
= 1.0.0 =
* Initial release
