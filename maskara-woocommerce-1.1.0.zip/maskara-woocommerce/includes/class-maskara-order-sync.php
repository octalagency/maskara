<?php
if (!defined('ABSPATH')) {
    exit;
}

class Maskara_Order_Sync {
    private $sent_meta_key = '_maskara_sent';

    public function __construct() {
        // Status transitions
        add_action('woocommerce_order_status_processing', array($this, 'maybe_send_order'), 10, 1);
        add_action('woocommerce_order_status_on-hold', array($this, 'maybe_send_order'), 10, 1);
        add_action('woocommerce_order_status_pending', array($this, 'maybe_send_order'), 10, 1);

        // Most reliable for new checkout orders (COD often lands here)
        add_action('woocommerce_checkout_order_processed', array($this, 'maybe_send_order'), 20, 1);
        add_action('woocommerce_thankyou', array($this, 'maybe_send_order'), 5, 1);
        add_action('woocommerce_new_order', array($this, 'maybe_send_order'), 20, 1);

        // Manual resend from order admin
        add_action('woocommerce_order_actions', array($this, 'add_order_action'));
        add_action('woocommerce_order_action_maskara_send', array($this, 'manual_send_order'));
    }

    public function add_order_action($actions) {
        $actions['maskara_send'] = 'Send / Resend to Maskara';
        return $actions;
    }

    public function manual_send_order($order) {
        if (!$order instanceof WC_Order) {
            return;
        }
        $order->delete_meta_data($this->sent_meta_key);
        $order->save();
        $this->maybe_send_order($order->get_id(), true);
    }

    public function maybe_send_order($order_id, $force = false) {
        if (get_option('maskara_connected', 'no') !== 'yes') {
            return;
        }

        $order = wc_get_order($order_id);
        if (!$order) {
            return;
        }

        if (!$force && $order->get_meta($this->sent_meta_key)) {
            return;
        }

        if (get_option('maskara_cod_only', 'yes') === 'yes' && !$this->is_cod_order($order)) {
            $order->add_order_note('Maskara: skipped — not COD (method: ' . $order->get_payment_method() . ' / ' . $order->get_payment_method_title() . '). Uncheck "COD Orders Only" in WooCommerce → Maskara if needed.');
            return;
        }

        if (empty($order->get_billing_phone())) {
            $order->add_order_note('Maskara: skipped — no billing phone number.');
            return;
        }

        $api = new Maskara_API();
        if (!$api->is_configured()) {
            $order->add_order_note('Maskara: skipped — API URL or API Key missing.');
            return;
        }

        $secret = get_option('maskara_webhook_secret', '');
        if (empty($secret)) {
            $order->add_order_note('Maskara: WARNING — Webhook Secret empty. Production API may reject order (401).');
        }

        $response = $api->parse_response($api->send_order($order));

        if (is_wp_error($response)) {
            $order->add_order_note('Maskara verification failed: ' . $response->get_error_message());
            return;
        }

        $order->update_meta_data($this->sent_meta_key, 'yes');
        $order->save();
        $dup = is_array($response) && !empty($response['duplicate']);
        $order->add_order_note($dup
            ? 'Maskara: order already exists (duplicate) — check Maskara dashboard.'
            : 'Maskara: order sent for AI voice verification.');
    }

    private function is_cod_order($order) {
        $method = strtolower((string) $order->get_payment_method());
        $title  = strtolower((string) $order->get_payment_method_title());

        $needles = array('cod', 'cash on delivery', 'cash-on-delivery', 'ক্যাশ', 'ক্যাশ অন', 'ক্যাশঅন');
        foreach ($needles as $n) {
            if ($n !== '' && (strpos($method, $n) !== false || strpos($title, $n) !== false)) {
                return true;
            }
        }

        return false;
    }
}
